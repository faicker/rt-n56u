#! /bin/bash

./run_ft_tests.sh $@ && ./run_gs_tests.sh $@
