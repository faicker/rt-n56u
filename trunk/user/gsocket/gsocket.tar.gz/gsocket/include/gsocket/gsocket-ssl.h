
#ifndef __LIBGSOCKET_SSL_H__
#define __LIBGSOCKET_SSL_H__ 1

/* The user can DELETE this file to build project without OpenSSL support */

#endif /* !__LIBGSOCKET_SSL_H__ */
