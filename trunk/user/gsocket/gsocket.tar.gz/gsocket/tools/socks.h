

#ifndef __GSNC_SOCKS_H__
#define __GSNC_SOCKS_H__ 1

int SOCKS_init(struct _peer *p);
int SOCKS_add(struct _peer *p);

#endif /* !__GSNC_SOCKS_H__ */